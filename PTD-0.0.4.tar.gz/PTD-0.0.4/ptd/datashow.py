import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

def show_scatter_curve(X,Y,pres):
	plt.scatter(X, Y) 
	plt.plot(X, pres) 
	plt.show()

def show_scatter(X,Y):
	if X.ndim>1:
		show_3d_scatter(X,Y)
	else:
		plt.scatter(X, Y) 
		plt.show()


def show_3d_scatter(X,Y):
	x = X[:,0]
	z = X[:,1]
	fig = plt.figure()
	ax = Axes3D(fig)
	ax.scatter(x, z, Y)
	plt.show()

def show_surface(x,z,forward_propgation):
	x = np.arange(np.min(x),np.max(x),0.1)
	z = np.arange(np.min(z),np.max(z),0.1)
	x,z = np.meshgrid(x,z)
	y = forward_propgation(X)
	fig = plt.figure()
	ax = Axes3D(fig)
	ax.plot_surface(x, z, y, cmap='rainbow')
	plt.show()

def show_surface1(x,z,y):
	x = np.arange(np.min(x),np.max(x),0.1)
	z = np.arange(np.min(z),np.max(z),0.1)
	x,z = np.meshgrid(x,z)
	y = np.array(y) 
	fig = plt.figure()
	ax = Axes3D(fig)
	ax.plot_surface(x, z, y, cmap='rainbow')
	plt.show()

def show_scatter_surface(X,Y,forward_propgation):
	x = X[:,0]
	z = X[:,1]
	y = Y

	fig = plt.figure()
	ax = Axes3D(fig)
	ax.scatter(x, z, y)

	x = np.arange(np.min(x),np.max(x),0.1)
	z = np.arange(np.min(z),np.max(z),0.1)
	x,z = np.meshgrid(x,z)

	X = np.column_stack((x[0],z[0]))
	for j in range(z.shape[0]):
		if j == 0:
			continue
		X = np.vstack((X,np.column_stack((x[0],z[j]))))

	r = forward_propgation(X)
	y = r[0]
	if type(r) == np.ndarray:
		y = r

	
	y = np.array([y])
	y = y.reshape(x.shape[0],z.shape[1])
	ax.plot_surface(x, z, y, cmap='rainbow')
	plt.show()



def losses(loss_a,loss_b,label1, label2):
	# plot中参数的含义分别是横轴值，纵轴值，线的形状，颜色，透明度,线的宽度和标签
	plt.plot([i for i in range(len(loss_a))], loss_a, 'r-', color='r', alpha=0.8, linewidth=1, label=label1)
	plt.plot([i for i in range(len(loss_b))], loss_b, 'b-', color='b', alpha=0.8, linewidth=1, label=label2)
	# 显示标签，如果不加这句，即使在plot中加了label='一些数字'的参数，最终还是不会显示标签
	plt.legend(loc="upper right")
	plt.xlabel('Iteration count')
	plt.ylabel('loss')

	plt.show()
	plt.savefig('loss.svg')  # 保存该图片
# losses([3,2,1],[5,4,3],'1','2')