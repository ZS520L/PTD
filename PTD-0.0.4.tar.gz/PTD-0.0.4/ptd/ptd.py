import numpy as np
from numpy import random as rd
import matplotlib.pyplot as plt
import copy
from typing import *


class PTD:
  """
  参数说明：
    NN_nums:NN_nums[0]-输入特征维度  NN_nums[-1]-输出维度  NN_nums[1:-1]-中间层神经元数量
    N：迭代次数
    xs:输入样本数据
    ys：输入样本标签

  测试说明：
    测试时将test样本和标签覆盖self.xs和self.ys即可
  """
  
  def __init__(self, NN_nums: List[int], N: int, xs: List[List] = [], ys: List[int] = []):
    """
    #NN_nums = [2, 3, 3, 3, 1]  #输入层 中间层 输出层维度
    """
    self.NN_nums = NN_nums
    self.N = N
    self.loss = []
    self.xs = xs
    self.ys = ys
    self.inputs = []
    self.res = []


  def rv2dm(self,rv):
    """
    Row vectors to Diagonal matrix
    """
    rv = np.array(rv)
    wh = rv.shape[0]
    da = np.zeros([wh,wh])
    for i in range(wh):
      da[i,i] = rv[i]
    return da

  def NN(self):
    #NN_nums = [2, 3, 3, 3, 1]  #输入层 中间层 输出层维度
    NN_nums = self.NN_nums
    W = []
    B = []
    S = []
    W1 = []#save grad
    B1 = []#save grad
    S1 = []
    for i in range(len(NN_nums)-1):
      # w = rd.randn(NN_nums[i], NN_nums[i+1]).astype(np.float64)
      w = np.random.randint(-4, 4, (NN_nums[i], NN_nums[i+1])).astype(np.float64)
      # b = rd.randn(1, NN_nums[i+1]).astype(np.float64)
      b = np.random.randint(-4, 4, (1, NN_nums[i+1])).astype(np.float64)
      # s = 5*rd.randn(1, NN_nums[i+1]).astype(np.float64)
      # s = np.random.rand(NN_nums[i+1]).reshape(1,-1)
      s = np.random.randint(1, 2, (1, NN_nums[i+1])).astype(np.float64)#array([[1., 1., 1.]])
      W.append(w)   
      B.append(b)
      S.append(s)
    self.W = W
    self.B = B
    self.S = S
    self.W1 = copy.deepcopy(W)
    self.B1 = copy.deepcopy(B)
    self.S1 = copy.deepcopy(S)
    # print(len(self.B1))


  def fit(self):
    # print(self.xs)
    self.NN()

    for _ in range(self.N):
      zz = 0
      flag = 0
      for i,j in zip(self.xs, self.ys):
        
        # z = (j - self.forward(i,1))**2 #loss
        if isinstance(j,int) or isinstance(j,float):
          z = (j - self.forward(i,1))**2
        else:
          # print(1111)
          # z = -1*(np.array(j).reshape(1,-1)).dot(np.log(self.forward(i,1)).T)#ce
          z = np.sum(((np.array(j).reshape(1,-1))-(self.forward(i,1)))**2)
        flag += 1
        try:
          zz += z[0][0]
        except Exception:
          zz += z
        
        
        for index1,item1 in enumerate(self.B):
          for index2,item2 in enumerate(item1):
            for index3,item3 in enumerate(item2):
              self.B[index1][index2][index3] += 0.00000001
              if isinstance(j,int) or isinstance(j,float):
                z1 = (j - self.forward(i,0))**2
                # print(11111)
              # self.B1[index1][index2][index3] = self.alpha*((z1-z)/0.001)[0][0]
              else:
                # z1 = -1*(np.array(j).reshape(1,-1)).dot(np.log(self.forward(i,0)).T)
                z1 = np.sum(((np.array(j).reshape(1,-1))-(self.forward(i,0)))**2)
              try:
                self.B1[index1][index2][index3] = (z1[0][0]-z[0][0])/0.00000001 
              except Exception:
                self.B1[index1][index2][index3] = (z1-z)/0.00000001 
              self.B[index1][index2][index3] -= 0.00000001


        
        # print(len(self.B1))
        for i in range(len(self.B1)):
          # print(len(self.inputs))
          self.W1[i] = (((self.inputs[i])).T).dot(self.B1[i])
          # self.S1[i] = self.B1[i].dot((self.rv2dm(   ((self.inputs[i].dot(self.W[i]) + self.B[i]).dot(self.rv2dm(1/(self.S[i].reshape(-1,))))).reshape(-1,)  )))
          # print(self.S1[i])    
          # s 
    
        for i in range(len(self.B)):#待更新梯度（固定步长学习率）
          self.W[i] -= (2*self.sigmoid(np.array(self.W1[i]))-1)#待更新梯度（待更新梯度压缩）
          self.B[i] -= (2*self.sigmoid(np.array(self.B1[i]))-1)

          #(2./(1+exp(-1/2*x*16))-1)./2;
          # self.W[i] -= (2*self.sigmoid(np.array(self.W1[i])*36)-1)/3#待更新梯度（待更新梯度压缩）   16 2
          # self.B[i] -= (2*self.sigmoid(np.array(self.B1[i])*36)-1)/3
          # self.S[i] -= (2*self.sigmoid(np.array(self.S1[i])*36)-1)/3  # 越小越缓?why not is4.5
          # self.W[i] -= self.W1[i]*0.5
          # self.B[i] -= self.B1[i]*0.5
          # self.W[i] -= (self.W1[i]/5)**3
          # self.B[i] -= (self.B1[i]/5)**3
      # s
      self.loss.append(zz/len(self.xs))
      # print(self.W1[0])
      print(_, zz/len(self.xs))
  def predict(self): # 二分类预测
    res = []
    for i in self.xs:
      z = self.forward(i,0) #get normal z
      res.append(z[0][0])
    self.res = res
    num = 0
    for i,j in zip(res,self.ys):
      if round(i)==int(j):
        num += 1
    print("accuracy",num/len(res))

  def predict1(self): # 多分类预测
    self.res = []
    for i in self.xs:
      z = self.forward(i,0) #get normal z
      self.res.append(z[0])

    num = 0
    for i,j in zip(self.res,self.ys):
      if i.tolist().index(max(i))==j.tolist().index(max(j)):
        num += 1
    print("accuracy",num/len(self.ys),len(self.ys))

  def forward(self, x, flag:int = 0): # 前向传播
    x = np.array(x).reshape(1,-1) # <class 'numpy.ndarray'>
    W = self.W
    B = self.B
    S = self.S
    # print(W)
    l = len(W)
    if flag==1:
      del self.inputs
      self.inputs=[]
    for i in range(len(W)):
      if flag==1:#1 add
        # print(111111111111)
        self.inputs.append(x)
        # print(len(self.inputs))
      x = x.dot(W[i]) + B[i]
      if i== l-1:
        if len(x) == 1:
          x = self.sigmoid(x.dot(self.rv2dm(S[i].reshape(-1,))))
        else:
          x = self.softmax(x.dot(self.rv2dm(S[i].reshape(-1,))))
      else:
        x = self.acfun(x.dot(self.rv2dm(S[i].reshape(-1,))))#[[]]
        
    z = x
    return z

  def softmax(self, x):
    x = np.exp(x)
    z = x/np.sum(x)
    return z

  def forward1(self,x): # 输出预测结果，用于绘图
    x = np.array(x) # <class 'numpy.ndarray'>
    W = self.W
    B = self.B
    for i in range(len(W)):
      x = x.dot(np.array(W[i])) + np.array(B[i])
      x = self.sigmoid(x)
    z = x
    return z

  def sigmoid(self,x): # 输出层激活函数
    return 1/(1+np.exp(-x)) # 二分类
    # return x # 线性回归
    # 多分类激活函数内嵌到前线传播之中了


  def acfun(self,x): # 隐藏层激活函数
    # return 1/(1+np.exp(-x)) #sigmoid
    return 1/(1+np.exp(-1/2*x)) #ssigmoid
    # return np.where(x>0,x,0) #relu
    # return x*self.tanh(np.exp(x)) #TanhExp
    # return np.where(x>0,x,0.1*x) #LRelu
    # return np.where(x>0,x,0)+np.where(x<0,np.exp(x)-1,0) #ELU
    # return 1.0507*np.where(x>0,x,0)+np.where(x<0,1.6732*(np.exp(x)-1),0) #SELU
    
    # return np.where(x<1,np.where(x>0,(x+5)/10,0),1)
    # return 1/np.exp((1/3*x)**2)
    # return 1/np.exp(-4/15*x)-1
    # return x**2


  def tanh(self, x): # 辅助生成隐藏层激活函数
    return (np.exp(x) - np.exp(-x))/(np.exp(x) + np.exp(-x))  


  def display_loss(self): # 展示损失曲线，并返回损失数据
    plt.plot([i for i in range(len(self.loss))],self.loss)
    plt.show()
    return self.loss
  def get_beans(self,counts): # 内部测试数据生成函数
    xs = np.random.rand(counts)*2
    xs = np.sort(xs)
    ys = np.zeros(counts)
    for i in range(counts):
      x = xs[i]
      yi = 0.7*x+(0.5-np.random.rand())/50+0.5
      if yi > 0.8 and yi < 1.4:
        ys[i] = 1
    # ys = 2+3*xs
    self.xs = xs
    self.ys = ys

  def display(self): # 预测结合拟合展示
    X = self.xs
    C = self.ys
    plt.scatter(X,C)
    plt.plot(X,self.res)
    plt.show()
if __name__ == '__main__':
  bp = PTD(NN_nums=[1,12,12,1], N=100)
  bp.get_beans(100)
  bp.fit()
  bp.predict()
  ptd_loss = bp.display_loss()
  bp.display()