# PTD
A novel machine learning framework：Parallel Trace Differential
