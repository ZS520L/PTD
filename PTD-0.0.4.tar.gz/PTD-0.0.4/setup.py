import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="PTD",
    version="0.0.4",
    author="AUST001",
    author_email="2357872806@qq.com",
    description="A novel machine learning framework：Parallel Trace Differential.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ZS520L/PTD.git",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7.13',
)
